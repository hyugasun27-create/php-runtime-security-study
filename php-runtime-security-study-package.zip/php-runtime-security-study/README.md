# PHP Runtime Security Study — Purple Hat Lab Journal

A portfolio-oriented study of PHP runtime security, memory-safety risk, Linux troubleshooting, and defensive validation, informed by an authorized TryHackMe exercise and the PHP team's public security advisory issued on 21 October 2026.

> **Public portfolio edition:** This repository deliberately does not publish room flags, answer strings, room-specific exploit code, or a step-by-step walkthrough. TryHackMe's current Acceptable Use Policy restricts sharing those materials while content remains active. The notes focus on concepts, verified observations, defensive reasoning, and remediation.

## Why this project exists

I am developing a Purple Hat workflow: understand offensive concepts in an authorized lab, record verifiable evidence, map plausible attacker behavior to defensive telemetry, and recommend remediation that can be validated.

## What is included

- `docs/lab-observations.md` — a sanitized evidence timeline and troubleshooting lessons.
- `docs/defensive-analysis.md` — an attacker-to-defender mapping, detection hypotheses, and incident-response considerations.
- `remediation/hardening-checklist.md` — a patch-first checklist and post-remediation validation plan.
- `PHP2Shell_Purple_Hat_Report_Public.docx` — the formatted public edition of the lab report.
- `sources.md` — official references used for the technical context.

## Main learning areas

- Runtime-level vulnerabilities can occur before application-level validation or route logic has run.
- Memory-safety failures and incorrect cleanup after error paths can compromise process integrity.
- ASLR raises the difficulty of predicting addresses; it is not a patch for memory corruption.
- HTTP response metadata can aid inventory, but headers alone do not prove a vulnerability or exploitation.
- Host and container filesystems, users, and permissions must be verified rather than assumed.
- Strong findings separate observed evidence from hypotheses and unverified outcomes.
- Runtime patching is the primary remediation; configuration and network controls are only exposure-reduction measures unless the vendor explicitly says otherwise.

## Evidence and scope

The lab transcript confirmed that an SSH shell was available, the target's local HTTP endpoint returned a successful response, and an endpoint response included technology-identification headers. Some exact values and the short response body are intentionally omitted here because they were also direct challenge prompts. The session also captured a Linux permission-denied error and verified that a file was later readable via `sudo cat`.

The learner reported completing the room, but the conversation did not preserve a successful exploit proof line, a verified identity from the exploited process, or the exact flag. This repository therefore does **not** claim independent proof of remote command execution and does not invent a flag.

## How I approach the analysis

1. Establish scope and verify the service's behavior with low-impact observation.
2. Read provided scripts and documentation before execution.
3. Capture command output and label the strength of each conclusion.
4. Diagnose filesystem and container assumptions with minimal commands.
5. Map potential attack signals to telemetry while stating what was not collected.
6. Prioritize vendor remediation and verify the running deployment after patching.

## Public-use note

This repository is a learning summary, not a TryHackMe solution guide. Reproduction belongs only in an authorized lab or a system for which written permission exists. Review the room's current status and platform policy before publishing any additional room-specific detail.

## References

See [`sources.md`](sources.md) for the official PHP security advisory and TryHackMe policy links.
