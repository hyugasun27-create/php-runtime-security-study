# Sources

Accessed 23 October 2026. These links support the general technical and policy context in this portfolio summary.

1. **PHP official security advisory archive**, “Critical remote code execution vulnerabilities, update now” (21 October 2026): https://www.php.net/archive/2026.php#2026-10-21-5
   - Official explanation of the vulnerability family, affected runtime scenarios, fixed releases, and the limits of mitigations.
2. **PHP release announcement** (21 October 2026): https://news-web.php.net/php.announce/512
   - Official PHP release note associated with the security update.
3. **TryHackMe Acceptable Use Policy**, version 2.0 effective 28 August 2026: https://tryhackme.com/legal/acceptable-use-policy
   - Section 8 covers active-content restrictions on publishing flags, answers, room-specific exploit code, and step-by-step walkthroughs; unretired content should be treated as active.

Always re-check the current advisories and platform policy before public release or reuse. This repository does not substitute for vendor documentation or an authorized security assessment.
