# Sanitized screenshots

Add screenshots only after removing IPs, usernames, credentials, flags, answer strings, tokens, session identifiers, and any room-specific exploit output. Do not upload screenshots of active room answers or walkthrough steps. The current repository contains no screenshots.
