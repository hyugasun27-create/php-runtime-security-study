# Upload guide (GitHub web interface)

1. Open https://github.com/new and create a repository named `php-runtime-security-study`.
2. Choose **Public** only for this sanitized package. Do not upload the prior detailed private report unchanged.
3. Add a README on creation, then upload the files and folders from this package using **Add file → Upload files**.
4. Commit with a message such as `Add sanitized PHP runtime security study`.
5. Open the repository page and review every file, screenshot, and commit to ensure no flags, challenge answers, credentials, tokens, session IDs, or room-specific exploit steps were included.
6. Pin the repository to your profile after the README is polished.

Suggested root files: `README.md`, `sources.md`, `.gitignore`, `docs/`, `remediation/`, and `PHP2Shell_Purple_Hat_Report_Public.docx`.
